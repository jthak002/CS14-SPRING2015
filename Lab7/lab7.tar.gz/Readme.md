//***********************************
//*Name: Jeet Thakkar
//*SID: 861189089
//*Date: May 26, 2015
//*Lab 7
//***********************************

Part b:
Looking at the graph myplot.png, we see that for large inserts and finds, the
hash-table (the Unordered Set) performs marginally better than the Self 
balancing tree, which takes nearly twice the time as the hash table. However, 
the one advantage of a self balancing tree is, that, it's sorted. 

*The program has been compiled and run on hammer, while the graph was generated 
on well.
